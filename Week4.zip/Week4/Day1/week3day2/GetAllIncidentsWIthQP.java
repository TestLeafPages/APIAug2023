package week3day2;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentsWIthQP {
	
	@Test
	public void get() {
		
		// Give the endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		//Add Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
		
		//Add headers
		RequestSpecification inputRequest = RestAssured.given();
	//	.queryParam("sysparm_fields", "short_description,sys_id");
		
		//Send Request
		Response response = inputRequest.get("/incident");
		response.then().assertThat().statusLine(Matchers.equalTo("HTTP/1.1 204 No Content"));
		response.then().assertThat().body("result.number", Matchers.hasItem("INC00090021"));
		response.prettyPrint();

		
	}

}
