package week3day2;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithAssertion {

	@Test
	public void create() {

		// Specify the endpoint
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";

		// Authentication

		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");

		// Add Request Body and header

		RequestSpecification inputRequest = RestAssured
				.given()
				.contentType("application/json")
				.when()
				.body("{\r\n"
						+ "    \"short_description\": \"created via postman\",\r\n"
						+ "    \"description\": \"Description added via postman\"\r\n"
						+ "}");

		// Send Request

		Response response = inputRequest.post("/incident");

		//Assertions

		// Inbuilt RestAssured Assertion
	    //response.then().assertThat().statusCode(200);
		
		int statusCode = response.getStatusCode();
		
		String short_desc = response.jsonPath().get("result.short_description");

		//TestNG Hard Assertions
		//Assert.assertEquals(200, statusCode);
		Assert.assertEquals("created via postman", short_desc);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(200, statusCode);
	//	sa.assertAll();
		
		response.prettyPrint();




	}

}
