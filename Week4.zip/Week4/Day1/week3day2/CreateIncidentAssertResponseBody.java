package week3day2;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentAssertResponseBody {

	@Test
	public void createIncident() {
		
		// Specify the endpoint
				RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";

				// Authentication

				RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");

				// Add Request Body and header

				RequestSpecification inputRequest = RestAssured
						.given()
						.contentType("application/json")
						.when()
						.body("{\r\n"
								+ "    \"short_description\": \"created via postman\",\r\n"
								+ "    \"description\": \"Description added via postman\"\r\n"
								+ "}");

				// Send Request

				Response response = inputRequest.post("/incident");
				
				response.then().assertThat().body("result.number",Matchers.containsString("INC"));
				response.then().assertThat().body("result.short_description", Matchers.equalTo("created via postman1"));
		
	}
}
