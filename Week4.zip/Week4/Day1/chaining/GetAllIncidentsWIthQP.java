package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentsWIthQP extends BaseClass {
	
	@Test(dependsOnMethods = "chaining.CreateIncident.create")
	public void get() {
		
		
		//Add headers
		RequestSpecification inputRequest = RestAssured.given();
	//	.queryParam("sysparm_fields", "short_description,sys_id");
		
		//Send Request
		Response response = inputRequest.get("/incident");
	//	response.then().assertThat().statusLine(Matchers.equalTo("HTTP/1.1 204 No Content"));
		response.then().assertThat().body("result.number", Matchers.hasItem(incNum));
		response.prettyPrint();

		
	}

}
