package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends BaseClass {
    @Test(dependsOnMethods = "chaining.CreateIncident.create")          //packagename.classname.methodname
	public void update() {
		
    	
  
    	
    	// Add Request Body and header
		
    			 RequestSpecification inputRequest = RestAssured
    			.given()
    			.contentType("application/json")
    		    .when()
    			.body("{\r\n"
    					+ "    \"short_description\": \"updated via RA\",\r\n"
    					+ "    \"description\": \"Description added via RA\"\r\n"
    					+ "}");
    	
    	
    		Response response = inputRequest.put("/incident/"+sys_id);
    		
    		response.prettyPrint();
    	
    	
    	
	}
}
