package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class BaseClass {
	
	
	public static String sys_id;
	public static String incNum;
	
	@BeforeMethod
	public void setUp() {
		
		// Give the endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		//Add Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
	}

}
