package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteIncident extends BaseClass {
    @Test(dependsOnMethods ="chaining.UpdateIncident.update")
	public void delete() {
		
 	
    	
  
    	
    	
		
    		//	RequestSpecification inputRequest = RestAssured.given();
    	
    	
    		//Response response = inputRequest.delete("/incident/bf3599f42f70311081e256f62799b619");
    		
    	
    	    Response response = RestAssured.delete("/incident/"+sys_id);
    		int statusCode = response.statusCode();
    		System.out.println("Status Code for Delete is ------"+statusCode);
    	
    	
    	
	}
}
