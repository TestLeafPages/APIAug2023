package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends BaseClass {
	
	@Test
	public void create() {
		

		
		// Add Request Body and header
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.contentType("application/json")
	    .when()
		.body("{\r\n"
				+ "    \"short_description\": \"created via postman\",\r\n"
				+ "    \"description\": \"Description added via postman\"\r\n"
				+ "}");
		
		// Send Request
		
		 Response response = inputRequest.post("/incident");
		 
		 //Extract Sys_id
		 
		 sys_id=response.jsonPath().get("result.sys_id");
		 incNum=response.jsonPath().get("result.number");
		// Print Response
	//	response.prettyPrint();
		//response.prettyPeek();
		 response.then().assertThat().body("result.number",Matchers.containsString("INC"));
		
	}

}
