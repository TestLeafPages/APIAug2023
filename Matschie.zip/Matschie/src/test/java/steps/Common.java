package steps;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Common {
	public static RequestSpecification inputRequest;
	public static Response response;
	public static String sys_id;
}
