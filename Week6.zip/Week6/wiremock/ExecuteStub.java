package wiremock;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ExecuteStub {
    
	@Test
	public void execute() {
		// Give the endpoint
		
				RestAssured.baseURI="http://localhost/api/now/table";
				
				//Add Authentication
				
			//	RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
				
				// Add Request Body and header
				
				RequestSpecification inputRequest = RestAssured
				.given()
				.contentType("application/json")
			    .when()
				.body("{\r\n"
						+ "    \"short_description\": \"Updated via postman\",\r\n"
						+ "    \"description\": \"Description added via postman\"\r\n"
						+ "}");
				
				// Send Request
				
				 Response response = inputRequest.post("/incident");
				 
				 
				 
				// Print Response
				response.prettyPrint();
				//response.prettyPeek();
		
	}
}
