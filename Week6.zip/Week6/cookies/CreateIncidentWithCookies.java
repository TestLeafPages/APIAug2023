package cookies;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithCookies {
	
	@Test
	public void create() {
		
		// Give the endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		//Add Authentication
		
	
		
		// Add Request Body and header
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.cookie("JSESSIONID","4B5C37B9D0BC95D7920E71DDCB99A6A5")
		.contentType("application/json")
	    .when()
		.body("{\r\n"
				+ "    \"short_description\": \"created via postman\",\r\n"
				+ "    \"description\": \"Description added via postman\"\r\n"
				+ "}");
		
		// Send Request
		
		 Response response = inputRequest.post("/incident");
		 
		 
		 
		// Print Response
		response.prettyPrint();
		//response.prettyPeek();
		
		
	}

}
