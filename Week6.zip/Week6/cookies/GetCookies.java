package cookies;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetCookies {
    @Test
 	public void cookies() {

		// Give the endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		//Add Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
		
		// Add Request Body and header
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.contentType("application/json")
	    .when()
		.body("{\r\n"
				+ "    \"short_description\": \"created via postman\",\r\n"
				+ "    \"description\": \"Description added via postman\"\r\n"
				+ "}");
		
		// Send Request
		
		 Response response = inputRequest.post("/incident");
		 
		 String cookie = response.getCookie("JSESSIONID");
		 System.out.println("Value of JSession ID is ----"+cookie);
	}
}
