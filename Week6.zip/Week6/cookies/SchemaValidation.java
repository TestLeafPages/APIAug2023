package cookies;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SchemaValidation {

	@Test
	public void validateSchema() {
		
	// Give the endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		//Add Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
		
		// Add Request Body and header
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.contentType("application/json")
		.queryParam("sysparm_fields", "short_description,sys_id")
	    .when()
		.body("{\r\n"
				+ "    \"short_description\": \"created via postman\",\r\n"
				+ "    \"description\": \"Description added via postman\"\r\n"
				+ "}");
		
		// Send Request
		
		 Response response = inputRequest.post("/incident");
		 
		 File schemaFile= new File("./src/test/resources/JsonSchema.json");
		 response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schemaFile));
	}
	
}
